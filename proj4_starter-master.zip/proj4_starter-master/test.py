from test.test import run_test

if __name__ == '__main__':
  run_test()
